#!/usr/bin/env bash
# Stub bootstrap for substrate-init tests: writes a marker + manage.sh into --target.
set -e
TARGET="."
while [ $# -gt 0 ]; do case "$1" in --target) TARGET="$2"; shift 2;; *) shift;; esac; done
mkdir -p "$TARGET/.substrate"
echo "installed-by-substrate-init-stub" > "$TARGET/INSTALLED_BY_STUB"
printf '#!/usr/bin/env bash\necho stub-manage\n' > "$TARGET/manage.sh"
